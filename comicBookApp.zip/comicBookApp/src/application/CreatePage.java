package application;

import java.util.ArrayList;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Alert;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.control.Alert.AlertType;
import javafx.scene.effect.Blend;
import javafx.scene.effect.BlendMode;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.InnerShadow;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Priority;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class CreatePage extends Stage {

	
	public CreatePage() {
		
		
		ArrayList<ComicBook> comics = Records.preSetComicList();
		
		
	    // Label nodes
	    Label lblHeader = new Label ("Comicbook Search Engine");
	    Label lblPageHeader = new Label ("Create Comic Book");
	    Label lblTitle = new Label("Title:");
	    Label lblAuthor = new Label("Author:");
	    Label lblGenre = new Label("Genre:");
	    Label lblRating = new Label("Rating:");
	    Label lblDescription = new Label("Description:");
	    
	    
	    lblHeader.getStyleClass().add("lblHeader");
        lblPageHeader.getStyleClass().add("labelColor");
        lblTitle.getStyleClass().add("labelColor");
        lblAuthor.getStyleClass().add("labelColor");
        lblGenre.getStyleClass().add("labelColor");
        lblRating.getStyleClass().add("labelColor");
        lblDescription.getStyleClass().add("labelColor");
	    
	    
	    
        lblHeader.getStyleClass().add("lblHeader");
        
        Blend blend = new Blend();
        blend.setMode(BlendMode.MULTIPLY);

        DropShadow ds = new DropShadow();
        ds.setColor(Color.rgb(254, 235, 66, 0.3));
        ds.setOffsetX(5);
        ds.setOffsetY(5);
        ds.setRadius(5);
        ds.setSpread(0.2);

        blend.setBottomInput(ds);

        DropShadow ds1 = new DropShadow();
        ds1.setColor(Color.web("#f13a00"));
        ds1.setRadius(20);
        ds1.setSpread(0.2);

        Blend blend2 = new Blend();
        blend2.setMode(BlendMode.MULTIPLY);

        InnerShadow is = new InnerShadow();
        is.setColor(Color.web("#feeb42"));
        is.setRadius(9);
        is.setChoke(0.8);
        blend2.setBottomInput(is);

        InnerShadow is1 = new InnerShadow();
        is1.setColor(Color.web("#f13a00"));
        is1.setRadius(5);
        is1.setChoke(0.4);
        blend2.setTopInput(is1);

        Blend blend1 = new Blend();
        blend1.setMode(BlendMode.MULTIPLY);
        blend1.setBottomInput(ds1);
        blend1.setTopInput(blend2);

        blend.setTopInput(blend1);

        lblHeader.setEffect(blend);
	    
	    
	    
	    
	   // Text nodes
	    
	   TextField txtTitle = new TextField();
	   TextField txtAuthor = new TextField();
	   TextField txtGenre = new TextField();
	   TextField txtDescription = new TextField();
       txtDescription.setMaxHeight(Double.MAX_VALUE);
	   
	   // RadioButtons
	   
	   RadioButton optOne = new RadioButton();
	   RadioButton optTwo = new RadioButton();
	   RadioButton optThree = new RadioButton();
	   RadioButton optFour = new RadioButton();
	   RadioButton optFive  = new RadioButton();
	   
	
	   ToggleGroup grpRatings = new ToggleGroup();
	   optOne.setToggleGroup(grpRatings);
       optTwo.setToggleGroup(grpRatings);
       optThree.setSelected(true);
       optThree.setToggleGroup(grpRatings);
       optFour.setToggleGroup(grpRatings);
       optFive.setToggleGroup(grpRatings);
	   
       // buttons
       
      Button btnCancel = new Button("Cancel");
      Button btnSave = new Button("Save");
	   
      
	    
	    Insets mainLabelInset = new Insets(5, 5, 5, 5);
	    
	    
	    GridPane topPane = new GridPane();
	    BorderPane root = new BorderPane();
	    BorderPane centerPane = new BorderPane();
	    GridPane bottomPane = new GridPane();
	    HBox buttonsBox = new HBox();
	    
	    GridPane topGridPaneInCenter = new GridPane();
	    
	    
	    buttonsBox.getChildren().addAll(optOne,optTwo,optThree,optFour,optFive);
	    
	    
	    lblPageHeader.setAlignment(Pos.TOP_RIGHT);
	    topPane.add(lblHeader,0,0);
	    topPane.add(lblPageHeader,1,0);
	    topPane.setMargin(lblHeader,mainLabelInset);
        topPane.setMargin(lblPageHeader,mainLabelInset);
        topPane.setMargin(lblTitle,mainLabelInset);
        topPane.setMargin(lblAuthor,mainLabelInset);
        topPane.setMargin(lblGenre,mainLabelInset);
        topPane.setMargin(lblRating,mainLabelInset);
        topPane.setMargin(lblDescription,mainLabelInset);
        topPane.setMargin(txtTitle,mainLabelInset);
        topPane.setMargin(txtAuthor,mainLabelInset);
        topPane.setMargin(txtGenre,mainLabelInset);
        // centerPane.setHgap(5);
        // centerPane.setVgap(5);

        txtTitle.setMaxWidth(Double.MAX_VALUE);
        txtAuthor.setMaxWidth(Double.MAX_VALUE);
        txtGenre.setMaxWidth(Double.MAX_VALUE);
        topGridPaneInCenter.setMaxWidth(450.0);
        GridPane.setHgrow(txtTitle, Priority.ALWAYS);
        
        
        topGridPaneInCenter.add(lblTitle, 1, 1);
        topGridPaneInCenter.add(txtTitle, 2, 1);
        topGridPaneInCenter.add(lblAuthor, 1, 2);
        topGridPaneInCenter.add(txtAuthor, 2, 2);
        topGridPaneInCenter.add(lblGenre, 1, 3);
        topGridPaneInCenter.add(txtGenre, 2, 3);
        topGridPaneInCenter.add(lblRating, 1, 4);
        topGridPaneInCenter.add(buttonsBox, 2, 4);
        topGridPaneInCenter.add(lblDescription, 1, 5);
        
        
        centerPane.setTop(topGridPaneInCenter);
        
        
        centerPane.setCenter(txtDescription);
      //  CenterPane.setMargin(txtDescription,mainLabelInset);

        
        bottomPane.add(btnCancel, 1, 1);
        bottomPane.add(btnSave, 2, 1);
        bottomPane.setHgap(50);
        bottomPane.setVgap(5);
        bottomPane.setAlignment(Pos.BOTTOM_RIGHT);
        
        
	    root.setTop(topPane);
	    root.setCenter(centerPane);
	    root.setBottom(bottomPane);
	    
	    Scene scene = new Scene(root);
        
	    this.setScene(scene);
	    initModality(Modality.APPLICATION_MODAL);
	    
	    String stylesheet = getClass().getResource("application.css").toExternalForm();

	    scene.getStylesheets().add(stylesheet);
	    


	    btnSave.setOnAction(new EventHandler<ActionEvent>(){
            @Override
            public void handle(ActionEvent event){
            	

            	
           	 try{
             	Records.addComic(comics, txtTitle.getText(), txtAuthor.getText(), 2,txtGenre.getText(), txtDescription.getText());
       		 Alert emptySearch = new Alert(AlertType.INFORMATION);
       		 emptySearch.setHeaderText("Success");
       		 String message = "Your comic book has been added. :)";
       		 emptySearch.setContentText(message);
       		 emptySearch.show();
             	
       		 System.out.println(comics.toString());
             	
        	 }catch(Exception e){
        		 Alert emptySearch = new Alert(AlertType.INFORMATION);
        		 emptySearch.setHeaderText("Error adding comic");
        		 String message = "Sorry. Could not add comic. :(";
        		 emptySearch.setContentText(message);
        		 emptySearch.show();
        	 }
            	
            }
        });
	    
	    
	}
	
}
