package application;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.ListIterator;

public class Records {
    
     public static void printComicList(ArrayList<ComicBook> comicBookList){
            for (Iterator<ComicBook> it = comicBookList.iterator(); it.hasNext();) {
                ComicBook comics = it.next();
                System.out.println(comics);
            }
     }
     
     // We probably don't need this here.
     public static String nextRecord(ArrayList<ComicBook> comicBookList){
          String elements = "";
          ListIterator<ComicBook> it = comicBookList.listIterator();
           while(it.hasNext()){
        	   elements =  ("index: " + it.nextIndex() + " value: " + it.next());
        	   // System.out.println("index: " + it.nextIndex() + " value: " + it.next());
           }
           return elements;   
     }
         
     public static ArrayList<ComicBook> searchComic(ArrayList<ComicBook> comics, String searchKey){
        ArrayList<ComicBook> ary = new ArrayList<ComicBook>();
        for(int i=0; i<comics.size();i++){
            if(comics.get(i).getTitle().toLowerCase().contains(searchKey.toLowerCase()))
                ary.add(comics.get(i));
        }
        return ary;
    }
     
  
     // test this
     public static ArrayList<ComicBook> deleteComic(ArrayList<ComicBook> comicBookList,String searchKey){
         
         ComicBook deletedComic = new ComicBook("random",10, "bob");
         
        for(int i=0; i<comicBookList.size(); i++){
             if(comicBookList.get(i).getTitle().toLowerCase().contains(searchKey.toLowerCase())){
                 
                 deletedComic = comicBookList.get(i);
                     comicBookList.remove(comicBookList.get(i));
               
                 }
             }
         
           System.out.println(deletedComic + "has been deleted");
           
         return comicBookList;   
     }
     
     // test this
     public static void addComic(ArrayList<ComicBook> comicBookList, String title, String author,int rating, String genre, String description){
         
    	 Boolean g = genre == "null" || title.equals("");
    	 Boolean d = description == "null" || description.equals("");
    	 
    	 ComicBook comicName;
    	 
    	 if (g && d){comicName = new ComicBook(title,rating,author);}
    	 else if(g && !d){comicName = new ComicBook(title,rating,author, description);}
    	 else if(!g && d){comicName = new ComicBook(title,genre,rating,author);}
    	 else{comicName = new ComicBook(title,rating,author, genre, description);}
    	 
         comicBookList.add(comicName);
         
     }
     
     // test this
     public static void editComic(ArrayList<ComicBook> comicBookList, int index, String title, String author, int rating, String genre, String description){
         
         comicBookList.get(index).setTitle(title);
         comicBookList.get(index).setAuthor(author);
         comicBookList.get(index).setRating(rating);
         comicBookList.get(index).setGenre(genre);
         comicBookList.get(index).setDescription(description);
     }

     
     // test this
     public static void showDescription(ArrayList <ComicBook> comicBookList,String searchKey){
         
         ComicBook descriptionOfComic = new ComicBook("random",10, "Bob");
         String comicDescription = "";
         
        for(int i=0; i<comicBookList.size(); i++){
           if(comicBookList.get(i).getTitle().toLowerCase().contains(searchKey.toLowerCase())){
               
               descriptionOfComic  = comicBookList.get(i);
               comicDescription = comicBookList.get(i).getDescription();
               }
           }
         System.out.println(descriptionOfComic+ " descrption's is" + comicDescription);
     }
     
     // test this
     public static void addDescription(ArrayList<ComicBook> comicBookList,String searchKey, String description){
         
         ComicBook addDescriptionComic = new ComicBook("random",10,"bob");
         
        for(int i=0; i<comicBookList.size(); i++){
           if(comicBookList.get(i).getTitle().toLowerCase().contains(searchKey.toLowerCase())){
               
               addDescriptionComic  = comicBookList.get(i);
               comicBookList.get(i).setDescription(description);
               }
           }
       
         System.out.println(addDescriptionComic+ " descrption has been added");
       
   }
     
     public static ArrayList<ComicBook> preSetComicList(){
         
         ComicBook comicName1 = new ComicBook ("SuperMan",5, "joe");
         ComicBook comicName2 = new ComicBook ("Wonder Woman",5, "lance");
         ComicBook comicName3 = new ComicBook ("Black Panther",5,"Bob");
         ComicBook comicName4 = new ComicBook ("Batman",5,"Andrew");
         ComicBook comicName5 = new ComicBook ("ManCalvin",5, "Tanaka");
         ComicBook comicName6 = new ComicBook ("HobbesMan",6, "Tana");
         ComicBook comicName7 = new ComicBook ("Tomo The Super Hero",7, "T");
         
    	 ArrayList<ComicBook> comicBookList = new ArrayList<ComicBook>(
   			  Arrays.asList(
   			    comicName1,comicName2,comicName3,comicName4,comicName5,
   			     comicName6,comicName7
   			     )
   			  );
    	 return comicBookList;
     }
}