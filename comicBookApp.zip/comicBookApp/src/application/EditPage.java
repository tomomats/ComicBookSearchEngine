package application;

import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import javafx.scene.effect.Blend;
import javafx.scene.effect.BlendMode;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.InnerShadow;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.ColumnConstraints;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.paint.Color;
import javafx.stage.Modality;
import javafx.stage.Stage;

public class EditPage extends Stage {

	public EditPage() {
		
        // Labels
        Label lblHeader = new Label("Comicbook Search Engine");
        Label lblEditComicsTitle = new Label("Edit Comic Books");
        Label lblTitle = new Label("Title:");
        Label lblAuthor = new Label("Author:");
        Label lblGenre = new Label("Genre:");
        Label lblRating = new Label("Rating:");
        Label lblDescription = new Label("Description");
        
        
        
        lblHeader.getStyleClass().add("lblHeader");
        
        Blend blend = new Blend();
        blend.setMode(BlendMode.MULTIPLY);

        DropShadow ds = new DropShadow();
        ds.setColor(Color.rgb(254, 235, 66, 0.3));
        ds.setOffsetX(5);
        ds.setOffsetY(5);
        ds.setRadius(5);
        ds.setSpread(0.2);

        blend.setBottomInput(ds);

        DropShadow ds1 = new DropShadow();
        ds1.setColor(Color.web("#f13a00"));
        ds1.setRadius(20);
        ds1.setSpread(0.2);

        Blend blend2 = new Blend();
        blend2.setMode(BlendMode.MULTIPLY);

        InnerShadow is = new InnerShadow();
        is.setColor(Color.web("#feeb42"));
        is.setRadius(9);
        is.setChoke(0.8);
        blend2.setBottomInput(is);

        InnerShadow is1 = new InnerShadow();
        is1.setColor(Color.web("#f13a00"));
        is1.setRadius(5);
        is1.setChoke(0.4);
        blend2.setTopInput(is1);

        Blend blend1 = new Blend();
        blend1.setMode(BlendMode.MULTIPLY);
        blend1.setBottomInput(ds1);
        blend1.setTopInput(blend2);

        blend.setTopInput(blend1);

        lblHeader.setEffect(blend);
        
        
        
        
        //Text Fields
        TextField txtTitle = new TextField(),
        txtAuthor = new TextField(),
        txtGenre = new TextField(),
        txtDescription = new TextField();
        
        txtTitle.setPromptText("Title:");
        txtAuthor.setPromptText("Author:");
        txtGenre.setPromptText("Genre:");
        txtDescription.setPromptText("Description:");
        
        
        
        // Radio Buttons
        ToggleGroup radioGroup = new ToggleGroup();
        
        RadioButton opt1 = new RadioButton("1");
        RadioButton opt2 = new RadioButton("2");
        RadioButton opt3 = new RadioButton("3");
        RadioButton opt4 = new RadioButton("4");
        RadioButton opt5 = new RadioButton("5");
        
        opt1.setToggleGroup(radioGroup);
        opt2.setToggleGroup(radioGroup);
        opt3.setToggleGroup(radioGroup);
        opt4.setToggleGroup(radioGroup);
        opt5.setToggleGroup(radioGroup);
        
        // Buttons
        Button btnCancel = new Button("Cancel"), 
        btnDelete = new Button("Delete"),
        btnSave = new Button("Save");
        
        // Panes / Boxes
        // This is the root
        BorderPane root = new BorderPane();
        
        // In the top of the root, we will have the main title
        // and edit comics sub title
        GridPane gridPaneForTop = new GridPane();
        gridPaneForTop.add(lblHeader, 1, 1);
        gridPaneForTop.add(lblEditComicsTitle, 4, 1);
        
        gridPaneForTop.setHgap(100);
        gridPaneForTop.setVgap(5);
        
        // In the bottom of the root, we will have a cancel, 
        // delete, and save button.
        GridPane gridPaneForBottom = new GridPane();
        gridPaneForBottom.add(btnCancel, 3, 1);
        gridPaneForBottom.add(btnDelete, 4, 1);
        gridPaneForBottom.add(btnSave, 5, 1);
        
        // HBox for radio buttons
        HBox hBoxForRadio = new HBox();
        hBoxForRadio.getChildren().addAll(opt1,opt2,opt3,opt4,opt5);
        
        
        // In the center of the root (border pane), we will have labels (title, author,
        // genre, rating, and description) which will also be in a BorderPane.
        BorderPane centerBorderPane = new BorderPane();
        centerBorderPane.setMaxWidth(Double.MAX_VALUE);
        centerBorderPane.setMaxHeight(Double.MAX_VALUE);
        
        GridPane comicDataGridPane = new GridPane();
        
        comicDataGridPane.add(lblTitle, 0,0);
        comicDataGridPane.add(lblAuthor, 0,1);
        comicDataGridPane.add(lblGenre,0,2);
        comicDataGridPane.add(lblRating, 0,3);
        comicDataGridPane.add(lblDescription, 0,4);
        
        comicDataGridPane.add(txtTitle, 1,0);
        comicDataGridPane.add(txtAuthor, 1,1);
        comicDataGridPane.add(txtGenre, 1,2);
        comicDataGridPane.add(hBoxForRadio, 1, 3);
        comicDataGridPane.add(txtDescription, 1,4);
        
        // sets the spacing for the horizontal and vertical spacing between nodes
        comicDataGridPane.setHgap(5);
        comicDataGridPane.setVgap(5);
        
        // sets the spacing for the horizontal and vertical spacing between nodes and postion
        gridPaneForBottom.setHgap(5);
        gridPaneForBottom.setVgap(5);
        gridPaneForBottom.setAlignment(Pos.CENTER);
        
        // set the spacing between noded for the grid panes  
        Insets mainLabelInset = new Insets(5, 5, 5, 5);
        
        GridPane.setMargin(lblTitle, mainLabelInset);
        GridPane.setMargin(lblAuthor, mainLabelInset);
        GridPane.setMargin(lblGenre, mainLabelInset);
        GridPane.setMargin(lblRating, mainLabelInset);
        GridPane.setMargin(lblDescription, mainLabelInset);
        
        GridPane.setMargin(txtTitle,mainLabelInset);
        GridPane.setMargin(txtAuthor,mainLabelInset);
        GridPane.setMargin(txtGenre,mainLabelInset);
        GridPane.setMargin(txtDescription,mainLabelInset);
            
        GridPane.setMargin(btnCancel,mainLabelInset);
        GridPane.setMargin(btnDelete,mainLabelInset);
        GridPane.setMargin(btnSave,mainLabelInset);
        
        // colmumn constraints for the nodes
        ColumnConstraints col1 = new ColumnConstraints();
        col1.setPercentWidth(50.0);
        comicDataGridPane.getColumnConstraints().addAll(col1, col1);
       
        txtTitle.setMaxWidth(Double.MAX_VALUE);
        txtTitle.setMaxWidth(Double.MAX_VALUE);
        
        // add the text box to center of screen
        centerBorderPane.setTop(comicDataGridPane);
        centerBorderPane.setCenter(txtDescription);
        txtDescription.setMaxHeight(Double.MAX_VALUE);

        // add all panes to scene
        root.setTop(gridPaneForTop);
        root.setBottom(gridPaneForBottom);
        root.setCenter(centerBorderPane);
        
        Scene scene = new Scene(root);
	    this.setScene(scene);
	    initModality(Modality.APPLICATION_MODAL);
	    
	    String stylesheet = getClass().getResource("application.css").toExternalForm();
	    scene.getStylesheets().add(stylesheet);
        
	}

}
